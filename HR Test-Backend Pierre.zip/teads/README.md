# Auction

The goal is to implement an algorithm for finding the winner and the winning price. Please implement the solution in the language of your choice (preferably Scala). Tests should be separated from your algorithm.

## Technical Overview
- NodeJS  
- Lodash  
- Cucumber
- Gherkin
- Chai


## Structure
```sh
 - src
    - model
    - controller
 - features
    - auction.feature (contains the Gherkin scenarios)
    - support
        - APIWorld
        - steps.js (all steps used in the scenarios)
    
```


## Installation

```sh
$ npm i
```

## Start the tests

```sh
$ npm run test
```

## Adding a scenario

You can edit the file auction.feature  