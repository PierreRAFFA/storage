const orderBy = require('lodash/orderBy');
const head = require('lodash/head');
const get = require('lodash/get');

class Auction {

  constructor() {
  }

  //////////////////////////////////////////////////////
  //////////////////////////////////////////////////////
  findWinner(product, bids) {
    let result = {
      buyer: null,
    };

    //sort the bids by bid
    const sortedBuyerBids = orderBy(bids, 'bid', 'desc');

    //define the highest bid
    const highestBid = head(sortedBuyerBids);

    //check if the product price has been reached
    if (get(highestBid, 'bid') >= product.price ) {

      //define the winner
      const winner = highestBid.buyer;

      //define the winning price
      let i = 0;
      do{
        i++;
      }while(sortedBuyerBids[i].buyer === winner && i < sortedBuyerBids.length);

      const winningPrice = Math.max(product.price, sortedBuyerBids[i].bid);

      //build the result
      result = {
        buyer: winner,
        price: winningPrice,
      };
    }

    return result;
  }
}

module.exports = Auction;