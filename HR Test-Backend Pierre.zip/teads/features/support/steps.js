const { Given, When, Then, defineSupportCode } = require('cucumber');
const { expect } = require('chai');
const get = require('lodash/get');

defineSupportCode(function({After, Before}) {

  //Before
  Before(function (scenarioResult, cb) {
    cb();
  });

  //After
  After(function (scenarioResult, callback) {
    callback();
  });
});

///////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////  INITIALISATIONS
Given('a product with a price of {int} euros', function (price) {
  this.createProduct(price);
});


///////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////  ACTIONS
When('the user {string} set a bid to {int} euros', function (buyerName, bid) {
  this.registerBid(buyerName, bid);
});

///////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////  EXPECTATIONS
Then('the winner is {string}', function (winnerName) {
  expect(get(this.findWinner(), 'buyer.name')).to.eql(winnerName);
});

Then('there is no winner', function () {
  expect(get(this.findWinner(), 'buyer')).to.eql(null);
});

Then('the winner price is {int} euros', function (winnerPrice) {
  expect(get(this.findWinner(), 'price')).to.eql(winnerPrice);
});


