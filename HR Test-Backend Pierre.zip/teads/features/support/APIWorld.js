const { setWorldConstructor } = require('cucumber');
const AuctionController  = require('../../src/controller/auction.controller');
const Product  = require('../../src/model/product.model');
const BuyerBid  = require('../../src/model/buyerBid.model');
const Buyer  = require('../../src/model/buyer.model');

class APIWorld {

  constructor() {
    this._product = [];
    this._buyers = {};
    this._bids = [];
    this._auctionController = new AuctionController();
  }

  //////////////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////// COMMENT
  createProduct(price) {
    this._product = new Product(price);
  }

  registerBid(buyerName, bid) {
    const buyer = this.getUserByName(buyerName) || this.createBuyer(buyerName);

    const buyerBid = new BuyerBid(buyer, bid);
    this._bids.push(buyerBid);
  }

  createBuyer(name) {
    const buyer = new Buyer(name);
    this._buyers[name] = buyer;
    return buyer;
  }

  getUserByName(name) {
    return this._buyers[name];
  }

  findWinner() {
    return this._auctionController.findWinner(this._product, this._bids);
  }
}

setWorldConstructor(APIWorld);